const searchInput = document.querySelector("#search");
const filters = [...document.querySelectorAll(".filter")];
const cards = [...document.querySelectorAll(".game-card")];
const emptyState = document.querySelector("#empty-state");
const resultCount = document.querySelector("#result-count");
let activeCategory = "all";

function updateGames() {
  const query = searchInput.value.trim().toLowerCase();
  let visible = 0;

  cards.forEach(card => {
    const matchesText = `${card.dataset.name} ${card.dataset.description} ${card.dataset.category}`
      .toLowerCase().includes(query);
    const categories = card.dataset.category.split(" ");
    const matchesCategory = activeCategory === "all" || categories.includes(activeCategory);
    const show = matchesText && matchesCategory;
    card.hidden = !show;
    if (show) visible++;
  });

  emptyState.hidden = visible !== 0;
  resultCount.textContent = `${String(visible).padStart(2, "0")} GAME${visible === 1 ? "" : "S"}`;
}

searchInput.addEventListener("input", updateGames);
filters.forEach(button => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.category;
    filters.forEach(filter => {
      const selected = filter === button;
      filter.classList.toggle("active", selected);
      filter.setAttribute("aria-pressed", String(selected));
    });
    updateGames();
  });
});

// Press "/" to focus search, unless the user is typing in a field.
document.addEventListener("keydown", event => {
  const tag = document.activeElement?.tagName;
  if (event.key === "/" && !["INPUT", "TEXTAREA"].includes(tag)) {
    event.preventDefault();
    searchInput.focus();
  }
});
updateGames();
